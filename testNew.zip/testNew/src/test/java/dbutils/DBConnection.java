package dbutils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

public class DBConnection {

    public static void main(String [] args) throws ClassNotFoundException {
        Class.forName("org.postgresql.Driver");
        try{
            String url = "jdbc:postgresql://jll-am-portscape-postgres-sandbox.postgres.database.azure.com:5432/chart-catalog";
            Properties props = new Properties();
            props.setProperty("user","provisioner@jll-am-portscape-postgres-sandbox");
            props.setProperty("password","eERePyHSsPL1M8vO");
            props.setProperty("ssl","true");
            Connection con = DriverManager.getConnection(url,props);
            System.out.println("dsnm"+con);
        }
        catch (Exception e){
            System.out.println(e.toString());
        }
    }
}