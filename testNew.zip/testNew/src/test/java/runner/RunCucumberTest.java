package runner;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;

/**
 * This class is needed to run Cucumber tests with JUnit
 */



@RunWith(Cucumber.class)
@CucumberOptions(
        features = "src/test/resources/features/",
        plugin="html:target/html-reports/index.html",
        glue = {"steps"},
        tags="@smoke"
)
public class RunCucumberTest {

}
